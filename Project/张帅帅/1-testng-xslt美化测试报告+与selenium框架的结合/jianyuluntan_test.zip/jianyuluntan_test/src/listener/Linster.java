package listener;

import java.util.List;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import mail.SendMail;
/**
 * @author 张帅帅
 * 事件监听器，当测试报告生成后自动发送到邮箱
 * 发件人和收件人邮箱配置在属性文件
 */
public class Linster extends TestListenerAdapter {

	@Override
	public void onFinish(ITestContext context) {
		super.onFinish(context);
		System.out.println("tests done");
		//得到所有的测试用例
		ITestNGMethod[] methods = this.getAllTestMethods();
		List<ITestResult> failedList = this.getFailedTests();
		List<ITestResult> passList = this.getPassedTests();
		//失败的测试用例
		System.out.println("testsCount:" + Integer.toString(methods.length));
		for (int i = 0; i < failedList.size(); i++) {
			ITestResult tr = failedList.get(i);
			System.out.println(tr.getInstanceName() + ":" + tr.getName() + "failed");
		}	
		System.out.println("********************");
		//成功的测试用例
		for (int i = 0; i < passList.size(); i++) {
			ITestResult tr = passList.get(i);
			System.out.println(tr.getInstanceName() + ":" + tr.getName() + "success");
		}	
		
		//测试用例执行结束后自动发送测试报告到邮箱
		try {
			SendMail sendMail = new SendMail();
			sendMail.Send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	

}
