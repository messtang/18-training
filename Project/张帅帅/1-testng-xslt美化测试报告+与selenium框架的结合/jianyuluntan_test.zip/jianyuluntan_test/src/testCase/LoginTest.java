package testCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseDriver;
import pages.IndexPage;
import pages.LoginPage;

public class LoginTest extends BaseDriver{
	
	LoginPage loginPage;

	@BeforeClass
	public void initPage() {
		IndexPage indexPage = new IndexPage(driver);
		loginPage = indexPage.btn_login_click();
	}

	@Test
	public void test_login_success() {
		loginPage.login_success("test","admintest");
	}

}
