package testCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseDriver;
import pages.IndexPage;

public class IndexTest extends BaseDriver{
	
	IndexPage indexPage;
	
	@BeforeClass
	public void initPage() {
		indexPage  = new IndexPage(driver);
	}
	
	@Test
	public void test_click_btn_login() throws InterruptedException {
		indexPage.btn_login_click();
	}

}
