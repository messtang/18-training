package testCase;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(listener.Linster.class)
public class TestDemo {

	@Test
	public void test_success() {
		System.out.println("test_success");
		assertEquals(1, 2);
		
	}
	
	@Test
	public void test_fail() {
		System.out.println("test_fail");
		assertEquals(1, 2);
		
	}

}
