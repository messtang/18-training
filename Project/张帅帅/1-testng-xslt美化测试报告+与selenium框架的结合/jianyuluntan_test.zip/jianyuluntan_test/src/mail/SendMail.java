package mail;

import utils.CompressedFileUtil;
import utils.MailUtil;
import utils.ReadProperties;
/**
 * @author 张帅帅
 * 发送邮件的类
 * 先压缩文件再发送
 */
public class SendMail {

	public void Send() throws Exception {
		String user = ReadProperties.getPropertyValue("user");
		String host = ReadProperties.getPropertyValue("host");
		String from_mail = ReadProperties.getPropertyValue("from_mail");
		String to_mail = ReadProperties.getPropertyValue("to_mail");
		String author_code = ReadProperties.getPropertyValue("author_code");
		String affix = ReadProperties.getPropertyValue("affix");
		String affixName = ReadProperties.getPropertyValue("affixName");
		String subject = ReadProperties.getPropertyValue("subject");
		String compressFrom = ReadProperties.getPropertyValue("compressFrom");
		String compressTo = ReadProperties.getPropertyValue("compressTo");
		
		//压缩文件
		CompressedFileUtil fillName = new CompressedFileUtil();
		fillName.compressedFile(compressFrom, compressTo);
		
		// 实例化对象
		MailUtil cn = new MailUtil();
		// 设置发件人地址、收件人地址和邮件标题
		cn.setAddress(from_mail, to_mail, subject);
		// 设置要发送附件的位置和标题
		cn.setAffix(affix, affixName);
		// 设置服务器，用户名和授权码
		cn.send(host, user, author_code);
	}
}
