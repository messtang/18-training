package base;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;

import utils.ReadProperties;

/**
 * @author 秋簌 初始化浏览器
 */

public class BaseDriver {

	// 初始化浏览器
	protected WebDriver driver;
	
	/**
	 * 父类的protected成员是包内可见的，并且对子类可见；
	 * 若子类与父类不在同一包中，那么在子类中，子类实例可以访问其从父类继承而来的protected方法，而不能访问父类实例的protected方法。
	 * @throws IOException
	 * @throws InterruptedException 
	 */

	@BeforeClass
	public void initBrowser() throws IOException {
		String driverName = ReadProperties.getPropertyValue("driverName");
		String driverPath = ReadProperties.getPropertyValue("driverPath");		
		System.setProperty(driverName, driverPath);
		System.out.println("浏览器初始化");	
		String baseUrl = ReadProperties.getPropertyValue("baseUrl");
		driver = new FirefoxDriver();
		driver.get(baseUrl);
	}

//	@AfterClass
	public void quitBrowser() {
		driver.quit();
	}

}
