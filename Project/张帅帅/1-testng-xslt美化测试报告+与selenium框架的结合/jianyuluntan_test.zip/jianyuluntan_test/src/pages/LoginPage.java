package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage{
	WebDriver driver;
	
	//构造方法初始化driver
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	//用户名
	public WebElement edit_username() {
		return driver.findElement(By.name("user"));		
	}
	//密码
	public WebElement edit_password() {
		return driver.findElement(By.name("pwd"));
	}
	//验证码
	public WebElement check_image() {
		return driver.findElement(By.id("captcha"));
	}
	public WebElement change_image() {
		return driver.findElement(By.id("resetcaptcha"));
	}
	public WebElement edit_code() {
		return driver.findElement(By.id("captchain"));
	}
	//记住我
	public WebElement choose_remember() {
		return driver.findElement(By.name("remember"));		
	}
	//登录按钮
	public WebElement btn_login() {
		return driver.findElement(By.id("submit"));
	}
	//首页
	//找回密码
	//注册
	
	

	//登录
	public void login_success(String username, String password) {
		edit_username().sendKeys(username);
		edit_password().sendKeys(password);
		btn_login().click();
	}

}
