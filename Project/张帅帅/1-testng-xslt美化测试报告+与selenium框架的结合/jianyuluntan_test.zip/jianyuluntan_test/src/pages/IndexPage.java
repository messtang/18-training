package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
/**
 * @author 张帅帅
 * index界面，初始界面
 */
public class IndexPage {
	WebDriver driver;
	
	//构造方法初始化driver
	public IndexPage(WebDriver driver) {
		this.driver = driver;
	}	
	
	//登录按钮
	public WebElement btn_login() {		
		return driver.findElement(By.linkText("登录"));
	}
	//注册
	//签到
	//发新帖
	//搜索
	//entertainment
	//原创
	//test
	//头像（悬浮窗）
	//箭头（调整顺序）
	
	public LoginPage btn_login_click() {
		btn_login().click();
		return new LoginPage(driver);
	}
	
	
}
