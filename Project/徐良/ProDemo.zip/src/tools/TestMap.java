package tools;

import java.util.List;
/**
 * 
 * 
 * @author �����Ա�
 * @see һ��key��Ӧ���valueֵ�ķ���ʵ���͹�����
 *
 *
 */
public class TestMap {

    public static void main(String[] args) {
        String key = "a";
 
        LinkedMultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
        multiValueMap.add(key, "a");
        multiValueMap.add(key, "b");
        multiValueMap.add(key, "c");
        multiValueMap.add(key, "d");
 
        List<String> values = multiValueMap.getValues(key);
        for (String v : values) {
            System.out.println(v); //��� a  b  c  d
        }
    }
}
