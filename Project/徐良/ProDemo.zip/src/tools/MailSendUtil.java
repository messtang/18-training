package tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailSendUtil {
	 private final static String host = "smtp.qq.com"; //服务器
	    private final static String formName = "2843833799@qq.com";//你的邮箱
	    private final static String password = "idvellqwonapdeca"; //授权码
	    private final static String replayAddress = "2843833799@qq.com"; //你的邮箱


	    public static void sendHtmlMail(MailInfo info)throws Exception{
	        info.setHost(host);
	        info.setFormName(formName);
	        info.setFormPassword(password);   //�����������Ȩ��~��һ��������
	        info.setReplayAddress(replayAddress);

	        Message message = getMessage(info);
	        // MiniMultipart����һ�������࣬����MimeBodyPart���͵Ķ���
	        Multipart mainPart = new MimeMultipart();
	        // ����һ������HTML���ݵ�MimeBodyPart
	        BodyPart html = new MimeBodyPart();
	        // ����HTML����
	        html.setContent(info.getContent(), "text/html; charset=utf-8");
	        mainPart.addBodyPart(html);
	        // ��MiniMultipart��������Ϊ�ʼ�����
	        message.setContent(mainPart);
	        Transport.send(message);
	    }

	    public static void sendTextMail(MailInfo info) throws Exception {

	        info.setHost(host);
	        info.setFormName(formName);
	        info.setFormPassword(password);   //�������Ȩ��~��һ��������
	        info.setReplayAddress(replayAddress);
	        Message message = getMessage(info);
	        //��Ϣ���͵�����
	        message.setText(info.getContent());

	        Transport.send(message);
	    }

	    private static Message getMessage(MailInfo info) throws Exception{
	        final Properties p = System.getProperties() ;
	        p.setProperty("mail.smtp.host", info.getHost());
	        p.setProperty("mail.smtp.auth", "true");
	        p.setProperty("mail.smtp.user", info.getFormName());
	        p.setProperty("mail.smtp.pass", info.getFormPassword());

	        // �����ʼ��Ự���Ժ�������֤������һ�������ʼ���session
	        Session session = Session.getInstance(p, new Authenticator(){
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(p.getProperty("mail.smtp.user"),p.getProperty("mail.smtp.pass"));
	            }
	        });
	        session.setDebug(true);
	        Message message = new MimeMessage(session);
	        //��Ϣ���͵�����
	        message.setSubject(info.getSubject());
	        //������Ϣ����
	        message.setReplyTo(InternetAddress.parse(info.getReplayAddress()));
	        //��Ϣ�ķ�����
	        message.setFrom(new InternetAddress(p.getProperty("mail.smtp.user"),"�����Ա�"));
	        // �����ʼ��Ľ����ߵ�ַ�������õ��ʼ���Ϣ��
	        message.setRecipient(Message.RecipientType.TO,new InternetAddress(info.getToAddress()));
	        // ��Ϣ���͵�ʱ��
	        message.setSentDate(new Date());


	        return message ;
	    }
	    
	    public void send() {
	    	 String mail = "2843833799@qq.com"; //目标
	         String title = "凉城以北d测试报告";
	         String content = readFile("D:\\output\\azhe.html");
	         MailInfo info = new MailInfo();
	         info.setToAddress(mail);
	         info.setSubject(title);
	         info.setContent(content);
	         try {
	             MailSendUtil.sendHtmlMail(info);
	         } catch (Exception e) {
	             System.out.print("完蛋d"+title+"发送失败");
	             e.printStackTrace();
	         }
		}
	    //filePathAndName : ��Ҫת����html�� ����·��
	    public String readFile(String filePathAndName) {
	    	  String fileContent = "";
	          try {
	              File f = new File(filePathAndName);
	              if(f.isFile()&&f.exists()){
	                  InputStreamReader read = new InputStreamReader(new FileInputStream(f),"UTF-8");
	                  BufferedReader reader=new BufferedReader(read);
	                  String line;
	                  while ((line = reader.readLine()) != null) {
	             //����ȡ�����ַ�ƴ��  
	                    fileContent += line;
	                  }
	                  read.close();
	              }
	          } catch (Exception e) {
	              System.out.println("失败");
	              e.printStackTrace();
	          }
	          System.out.println("fileContent:"+fileContent);
	          return fileContent;
		}
}
