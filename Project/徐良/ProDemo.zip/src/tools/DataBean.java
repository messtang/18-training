package tools;

import java.util.Collection;
import java.util.List;

import org.testng.IResultMap;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
public class DataBean {
	private IResultMap passTests;
	private IResultMap faildTests;
	private Collection<ITestNGMethod> failedTestsMethod;
	private List<DataBean> passdata;
	private List<DataBean> failddata;
	private int excludeTestsSize; //δִ�е�test����
	private int passedTestsSize; //����ͨ��������
	private int failedTestsSize; //����ʧ�ܵ�����
	private int skippedTestsSize; //��������������
	private int allTestsSize; //ȫ��ִ�еĲ��Ե�����
	private ITestNGMethod[] allTestsMethod; //ȫ��ִ�еĲ��Է���
	private Collection<ITestNGMethod> excludeTestsMethod; //δִ�еĲ��Է���
	private String testsTime; //���Ժ�ʱ
	private String passPercent; //����ͨ����
	private String testName; //���Է�����
	private String className; //��������
	private String duration; //������������
	private String params; //�����ò���
	private String description; //��������
	private List<String> output; //Reporter Output
	private String dependMethod; //������������
	private Throwable throwable; //�����쳣ԭ��
	private StackTraceElement[] stackTrace; // �쳣��ջ��Ϣ
 
	public int getExcludeTestsSize() {
		return excludeTestsSize;
	}
 
	public void setExcludeTestsSize(int excludeTestsSize) {
		this.excludeTestsSize = excludeTestsSize;
	}
 
	public int getPassedTestsSize() {
		return passedTestsSize;
	}
 
	public void setPassedTestsSize(int passedTestsSize) {
		this.passedTestsSize = passedTestsSize;
	}
 
	public int getFailedTestsSize() {
		return failedTestsSize;
	}
 
	public void setFailedTestsSize(int failedTestsSize) {
		this.failedTestsSize = failedTestsSize;
	}
 
	public int getSkippedTestsSize() {
		return skippedTestsSize;
	}
 
	public void setSkippedTestsSize(int skippedTestsSize) {
		this.skippedTestsSize = skippedTestsSize;
	}
 
	public int getAllTestsSize() {
		return allTestsSize;
	}
 
	public void setAllTestsSize(int allTestsSize) {
		this.allTestsSize = allTestsSize;
	}
 
	public String getPassPercent() {
		return passPercent;
	}
 
	public void setPassPercent(String passPercent) {
		this.passPercent = passPercent;
	}
 
	public String getTestName() {
		return testName;
	}
 
	public void setTestName(String testName) {
		this.testName = testName;
	}
 
	public String getClassName() {
		return className;
	}
 
	public void setClassName(String className) {
		this.className = className;
	}
 
	public String getDuration() {
		return duration;
	}
 
	public void setDuration(String duration) {
		this.duration = duration;
	}
 
	public String getParams() {
		return params;
	}
 
	public void setParams(String params) {
		this.params = params;
	}
 
	public String getDescription() {
		return description;
	}
 
	public void setDescription(String description) {
		this.description = description;
	}
 
	public List<String> getOutput() {
		return output;
	}
 
	public void setOutput(List<String> output) {
		this.output = output;
	}
 
	public String getDependMethod() {
		return dependMethod;
	}
 
	public void setDependMethod(String dependMethod) {
		this.dependMethod = dependMethod;
	}
 
	public Throwable getThrowable() {
		return throwable;
	}
 
	public void setThrowable(Throwable throwable2) {
		this.throwable = throwable2;
	}
 
	public StackTraceElement[] getStackTrace() {
		return stackTrace;
	}
 
	public void setStackTrace(StackTraceElement[] stackTrace) {
		this.stackTrace = stackTrace;
	}
 
	public void setTestsTime(String testsTime) {
		this.testsTime = testsTime;
	}
 
	public String getTestsTime() {
		return testsTime;
	}
 
	public void setAllTestsMethod(ITestNGMethod[] allTestsMethod) {
		this.allTestsMethod = allTestsMethod;
	}
 
	public ITestNGMethod[] getAllTestsMethod() {
		return allTestsMethod;
	}
 
	public void setExcludeTestsMethod(Collection<ITestNGMethod> excludeTestsMethod) {
		this.excludeTestsMethod = excludeTestsMethod;
	}
 
	public Collection<ITestNGMethod> getExcludeTestsMethod() {
		return excludeTestsMethod;
	}

	public Collection<ITestNGMethod> getFailedTestsMethod() {
		return failedTestsMethod;
	}

	public void setFailedTestsMethod(Collection<ITestNGMethod> failedTestsMethod) {
		this.failedTestsMethod = failedTestsMethod;
	}

	public IResultMap getFaildTests() {
		return faildTests;
	}

	public void setFaildTests(IResultMap faildTests) {
		this.faildTests = faildTests;
	}

	public IResultMap getPassTests() {
		return passTests;
	}

	public void setPassTests(IResultMap passTests) {
		this.passTests = passTests;
	}

	public List<DataBean> getPassdata() {
		return passdata;
	}

	public void setPassdata(List<DataBean> passdata) {
		this.passdata = passdata;
	}

	public List<DataBean> getFailddata() {
		return failddata;
	}

	public void setFailddata(List<DataBean> failddata) {
		this.failddata = failddata;
	}

}