package listener;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.TestListenerAdapter;
import org.testng.annotations.Test;

import freemarker.template.TemplateException;
import tools.DataBean;
import tools.FileCreate;
import tools.MailSendUtil;
import tools.ReporterData;

public class ListenerSon  extends TestListenerAdapter{
	//�������ΪTestNG�ı�����������
		@Override
		public void onFinish(ITestContext testContext) {
			
			DataBean data = new DataBean();
			ReporterData reporterData = new ReporterData();
			data = reporterData.testContext(testContext);
			
			List<DataBean> passdata = reporterData.testResults(data.getPassTests(), 0);
			List<DataBean> faliddata = reporterData.testResults(data.getFaildTests(), 0);
			data.setPassdata(passdata);
			data.setFailddata(faliddata);
			
			Map< String, Object> data1 = new HashMap<String, Object>();
			data1.put("data", data);
			FileCreate fileCreate = new FileCreate();
			try {
				fileCreate.Create(data1);
				MailSendUtil mail = new MailSendUtil();
				mail.send();
			} catch (TemplateException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
