package com.webtest.demo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;

public class TestDemo extends BaseTest{

	@BeforeMethod
	public void testLogin() throws InterruptedException {
		webtest.open("http://127.0.0.1:9999/index.php/denglu.html");
		Thread.sleep(1000);
		webtest.type("name=user", "admin");
		Thread.sleep(1000);
		webtest.type("name=pwd", "326831XUliang");
		Thread.sleep(1000);
		webtest.click("id=submit");
		assertTrue(webtest.isTextPresent("退出"));
	}
	
	@Test
	public void test1() throws InterruptedException {
//		webtest.click("css=fa fa-sign-out fa-lg");
//		Thread.sleep(2000);
		assertTrue(webtest.isTextPresent("退出"));
	}
	
	@Test
	public void test2() throws InterruptedException {
//		webtest.click("css=nav-item");
//		Thread.sleep(2000);
		assertTrue(webtest.isTextPresent("退出"));
	}
	@Test
	public void test3() {
	    assertEquals(1, 2);
	}
	@Test
	public void test4() {
	    assertEquals(2, 3);
	}
	@Test
	public void test5() {
	    assertEquals(3, 4);
	}
	
	
}
