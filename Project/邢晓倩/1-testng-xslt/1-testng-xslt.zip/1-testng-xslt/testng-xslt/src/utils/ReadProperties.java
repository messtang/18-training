package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
/**
 * @author ����
 * ��ȡ�����ļ��ķ���
 */
public class ReadProperties {
	public static final String filePath="propertie/testng-xslt.properties";
	
	public static String getPropertyValue(String key) throws IOException {
		Properties prop=new Properties();
		prop.load(new FileInputStream(new File(filePath)));
	
		return  prop.getProperty(key);
		
	}

}
